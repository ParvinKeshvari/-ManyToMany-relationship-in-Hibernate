package entity;

import javax.persistence.*;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "Userr")
public class Userr {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "User_Id")
    private long User_Id;

    @Column(name = "User_Name")
    private String User_Name;

    @Column(name = "create_date", nullable = false)
    private Date create_date;

    @ManyToMany(cascade = CascadeType.ALL, fetch=FetchType.LAZY)
    @JoinTable(name = "User_Role",
            joinColumns = { @JoinColumn(name = "User_Id") },
            inverseJoinColumns = { @JoinColumn(name = "Role_Id") })
    private List<Role> rolesInUser = new ArrayList<>();


    @ManyToMany(cascade = CascadeType.ALL, fetch=FetchType.LAZY)
    @JoinTable(name = "User_Permission",
            joinColumns = { @JoinColumn(name = "User_Id") },
            inverseJoinColumns = { @JoinColumn(name = "Permission_Id") })
    private List<Permission> permissionsInUser = new ArrayList<>();


    public Userr( String user_Name) {

        User_Name = user_Name;
    }
    public Userr( String user_Name, Date create_date) {

        User_Name = user_Name;
        this.create_date = create_date;
    }

    public Userr()
    {

    }

    public long getUser_Id() {
        return User_Id;
    }

    public void setUser_Id(long user_Id) {
        User_Id = user_Id;
    }

    public String getUser_Name() {
        return User_Name;
    }

    public void setUser_Name(String user_Name) {
        User_Name = user_Name;
    }


    public Date getCreate_date() {
        return create_date;
    }

    public void setCreate_date(Date create_date) {
        this.create_date = create_date;
    }

    public List<Role> getRoles() {
        return rolesInUser;
    }

    public void setRoles(List<Role> roles) {
        this.rolesInUser = roles;
    }

    public List<Permission> getPermissions() {
        return permissionsInUser;
    }

    public void setPermissions(List<Permission> permissions) {
        this.permissionsInUser = permissions;
    }

    public void addRole(Role role) {
        rolesInUser.add(role);
        //rolesInUser.usersInRole.add(this);
    }
    public void addPermission(Permission permission) {
        permissionsInUser.add(permission);
        //rolesInUser.usersInRole.add(this);
    }


}
