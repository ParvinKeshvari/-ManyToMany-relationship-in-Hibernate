package entity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "Role")
public class Role {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Role_Id")
    private long Role_Id;

    @Column(name = "Role_Name")
    private String Role_Name;

    @ManyToMany(fetch=FetchType.LAZY, mappedBy = "rolesInUser")
    private List<Userr> usersInRole = new ArrayList<>();

    @ManyToMany(cascade = CascadeType.ALL, fetch=FetchType.LAZY)
    @JoinTable(name = "Role_Permission",
            joinColumns = { @JoinColumn(name = "Role_Id") },
            inverseJoinColumns = { @JoinColumn(name = "Permission_Id") })
    private List<Permission> permissionsInRole = new ArrayList<>();




    public Role() {  }

    public Role(String role_Name) {
        Role_Name = role_Name;
    }

    public long getRole_Id() {
        return Role_Id;
    }

    public void setRole_Id(long role_Id) {
        Role_Id = role_Id;
    }

    public String getRole_Name() {
        return Role_Name;
    }

    public void setRole_Name(String role_Name) {
        Role_Name = role_Name;
    }

    public List<Userr> getUsers() {
        return usersInRole;
    }

    public void setUsers(List<Userr> users) {
        this.usersInRole = users;
    }

    public List<Permission> getPermissions() {
        return permissionsInRole;
    }

    public void setPermissions(List<Permission> permissions) {
        this.permissionsInRole = permissions;
    }

    public void addPermission(Permission permission) {
        permissionsInRole.add(permission);
        //rolesInUser.usersInRole.add(this);
    }


}
