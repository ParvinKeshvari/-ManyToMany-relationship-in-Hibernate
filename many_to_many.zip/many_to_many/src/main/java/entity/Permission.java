package entity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "Permission")
public class Permission {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Permission_Id")
    private long Permission_Id;

    @Column(name = "Permission_name")
    private String Permission_name;

    @ManyToMany(fetch=FetchType.LAZY, mappedBy = "permissionsInRole")
    private List<Role> rolesInpermissions = new ArrayList<>();

    @ManyToMany(fetch=FetchType.LAZY, mappedBy = "permissionsInUser")
    private List<Userr> userspermissions = new ArrayList<>();

    public Permission()
    {}
    public Permission(String permission_name) {
        Permission_name = permission_name;
    }

    public long getPermission_Id() {
        return Permission_Id;
    }

    public void setPermission_Id(long permission_Id) {
        Permission_Id = permission_Id;
    }

    public String getPermission_name() {
        return Permission_name;
    }

    public void setPermission_name(String permission_name) {
        Permission_name = permission_name;
    }


    public List<Role> getRoles() {
        return rolesInpermissions;
    }

    public void setRoles(List<Role> roles) {
        this.rolesInpermissions = roles;
    }

    public List<Userr> getUsers() {
        return userspermissions;
    }

    public void setUsers(List<Userr> users) {
        this.userspermissions = users;
    }

}
