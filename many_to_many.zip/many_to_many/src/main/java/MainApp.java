import entity.Permission;
import entity.Role;
import entity.Userr;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class MainApp {


    public static void main(String[] args) {
        Session session = null;
        Transaction transaction = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            transaction = session.getTransaction();
            transaction.begin();

            Permission permission1 = new Permission("SELECT");
            Permission permission2 = new Permission("INSERT");
            Permission permission3 = new Permission("UPDATE");
            Permission permission4 = new Permission("DELETE");


            Role role1 = new Role("db_datareader");
            Role role2 = new Role("db_datawriter");
            role1.addPermission(permission1);
            role2.addPermission(permission1);
            role2.addPermission(permission2);
            role2.addPermission(permission3);
            role2.addPermission(permission4);

            Date date = new Date();
            Userr user1 = new Userr("pari", date);
            Userr user2 = new Userr("ali", date);
            user1.addRole(role1);
            user2.addRole(role2);
            user1.addPermission(permission1);
            user2.addPermission(permission1);
            user2.addPermission(permission2);
            user2.addPermission(permission3);
            user2.addPermission(permission4);

            /*session.save(permission1);
            session.save(permission2);
            session.save(permission3);
            session.save(permission4);*/

            session.save(role1);
            session.save(role2);
            session.save(user1);
            session.save(user2);

            transaction.commit();

            System.out.println("Records saved successfully");

        } catch (Exception e) {
            if (transaction != null) {
                System.out.println("-- " + e.getMessage() +" -- Transaction is being rolled back.");
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
        HibernateUtil.shutdown();
    }
}