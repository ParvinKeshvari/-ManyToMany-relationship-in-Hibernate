👩‍💻 About Me : 👋 Hi, I’m @ParvinKeshvari. I am a Backend Developer from Iran. 
👀 I’m interested in C#, Java ,Sql Server, Asp.Net and WPF 
🔭 I’m working as a Software Engineer and backend for building web and windows applications. 
⚡ my .google scholar is: https://scholar.google.com/citations?user=zHxRND0AAAAJ&hl=en 
📫 How to reach me: https://www.linkedin.com/in/parvin-keshvari-960516152

The Many-To-Many mapping represents a collection-valued association where any number of entities can be associated with a collection of other entities. In a relational database, any number of rows of one entity can be referred to any number of rows of another entity.
I write a simple project on how the @ManyToMany annotation can be used for specifying this type of relationship in Hibernate.
In this example, we create a Multi-To-Many relationship between the user, Role, and Permission tables so that we have different Role for each user and different Permission for different Roles, and thus multiple Permission for users

